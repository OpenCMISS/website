function RunnableFunctionWrapper(aFunction)
{
  this.run = aFunction;
}

RunnableFunctionWrapper.prototype =
{
  QueryInterface: function(aIID)
  {
    if (aIID.equals(Components.interfaces.nsIRunnable) ||
        aIID.equals(Components.interfaces.nsISupports))
      return this;
    throw Components.results.NS_NOINTERFACE;
  }
};

function CmguiReadyFunction(zincCommandData)
  {
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
    window.commandData = zincCommandData

	 load_skin_files();
  
}

function scene1ReadyFunction(sceneViewer)
  {
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");


	 window.sceneViewer = sceneViewer;

    sceneViewer.setBackgroundColourRGB(1.0, 1.0, 1.0);

	window.commandData.executeCommand('gfx modify g_element output general clear circle_discretization 6 default_coordinate coordinates element_discretization "10*10*10" native_discretization none');
	window.commandData.executeCommand('gfx modify g_element output lines select_on material black selected_material default_selected');
	window.commandData.executeCommand('gfx mod g_e output surfaces select_on material default data general spectrum default selected_material default_selected render_shaded');
	window.commandData.executeCommand('gfx mod spectrum default linear reverse range 0 100 extend_above extend_below rainbow colour_range 0 1 ambient diffuse component 1');
	window.sceneViewer.setLookatParametersNonSkew(288.624, 3949.47, -1017.48, 288.624, 173.616, -1017.48, 0, 0, 1);
//	window.commandData.executeCommand('gfx modify g_element data data_points glyph sphere general size "0*0*0" centre 0,0,0 font default orientation normalised_count scale_factors "0.1*0.1*0.1" select_on material black selected_material default_selected');

	sceneViewer.perturbLines = true;
	sceneViewer.viewAll();
  
}


function load_skin_files()
{
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

    //window.commandData.executeCommand('print \"load_skin_files just entered\\n\"');
   
    // Note the downloading is asynchronous so we need to wait for all of these to finish before
    // continuing. The DownloadMonitor object keeps track of the number of downloads in progress.
    var dm = zincCreateDownloadMonitor(window.commandData, setup_skin_files);

	 zincDefineMemoryBlock( dm, "la_norm.exnode", "/la_norm.exnode");
	 zincDefineMemoryBlock( dm, "output.exelem", "/output.exelem");

	 zincDefineMemoryBlock( dm, "ra_norm.exnode", "/ra_norm.exnode");
	 zincDefineMemoryBlock( dm, "li_norm.exnode", "/li_norm.exnode");
	 zincDefineMemoryBlock( dm, "ri_norm.exnode", "/ri_norm.exnode");

	 zincDefineMemoryBlock( dm, "ltis_norm.exnode", "/ltis_norm.exnode");
	 zincDefineMemoryBlock( dm, "rtis_norm.exnode", "/rtis_norm.exnode");
	 zincDefineMemoryBlock( dm, "lpop_norm.exnode", "/lpop_norm.exnode");
	 zincDefineMemoryBlock( dm, "rpop_norm.exnode", "/rpop_norm.exnode");
	 zincDefineMemoryBlock( dm, "lepit_norm.exnode", "/lepit_norm.exnode");
	 zincDefineMemoryBlock( dm, "repit_norm.exnode", "/repit_norm.exnode");

	 zincDefineMemoryBlock( dm, "1_NF_norm.exnode", "/1_NF_norm.exnode");
	 zincDefineMemoryBlock( dm, "2and_more_NFs_norm.exnode", "/2and_more_NFs_norm.exnode");
	 zincDefineMemoryBlock( dm, "3and_more_NFs_norm.exnode", "/3and_more_NFs_norm.exnode");
	 zincDefineMemoryBlock( dm, "4and_more_NFs_norm.exnode", "/4and_more_NFs_norm.exnode");

//	 zincDefineMemoryBlock( dm, "la_normalised.exdata", "/la_normalised.exdata");
//	 zincDefineMemoryBlock( dm, "ra_normalised.exdata", "/ra_normalised.exdata");
//	 zincDefineMemoryBlock( dm, "li_normalised.exdata", "/li_normalised.exdata");
//	 zincDefineMemoryBlock( dm, "ri_normalised.exdata", "/ri_normalised.exdata");
}

function setup_skin_files()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.commandData.executeCommand("gfx read nodes memory:/la_norm.exnode;");
  window.commandData.executeCommand("gfx read elements memory:/output.exelem;");

//  window.commandData.executeCommand("gfx read data memory:/la_normalised.exdata;");

  var plugin = document.getElementById("heatmap_plugin");
  window.plugin = plugin;
  var windowId = plugin.window;

  zincCreateSceneViewer(plugin, window.commandData,
    scene1ReadyFunction);

}

function init()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  var minVersion = "0.6.0"
  var maxVersion = "0.6.4"

  if (zincCheckValidVersion(minVersion, maxVersion))
  {
	  zincInitialise(CmguiReadyFunction);
  }
  else
  {
    actualVersion = zincVersion();
    alert("The installed version of zinc is not valid for this application. \n" +
		 "Version installed : " + actualVersion +
		 "\nMinimum allowable version :" + minVersion +
		 "\nMaximum allowable version :" + maxVersion + "\n");
  }
}

//////////// DIFFERENT VIEWS ////////////
//View numbers: eye_point, interest_point, up_vector (here interest_point and up_vector the same, just changing the eye_point)
function anterior_view()
{
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

    var ex = {}, ey = {}, ez = {}, ix = {}, iy = {}, iz = {}, ux = {}, uy = {}, uz = {};
    window.sceneViewer.getLookatParameters(ex, ey, ez, ix, iy, iz, ux, uy, uz);

    window.sceneViewer.setLookatParametersNonSkew(ix.value, 3949.47, iz.value, ix.value, iy.value, iz.value, 0, 0, 1);
//    window.sceneViewer.setLookatParametersNonSkew(288.624, 3949.47, -1017.48, 288.624, 173.616, -1017.48, 0, 0, 1);

}

function posterior_view()
{
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

    var ex = {}, ey = {}, ez = {}, ix = {}, iy = {}, iz = {}, ux = {}, uy = {}, uz = {};
    window.sceneViewer.getLookatParameters(ex, ey, ez, ix, iy, iz, ux, uy, uz);

    window.sceneViewer.setLookatParametersNonSkew(ix.value, -3602.24, iz.value, ix.value, iy.value, iz.value, 0, 0, 1);
//    window.sceneViewer.setLookatParametersNonSkew(288.624, -3602.24, -1017.48, 288.624, 173.616, -1017.48, 0, 0, 1);
}

function left_side_view()
{
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

    var ex = {}, ey = {}, ez = {}, ix = {}, iy = {}, iz = {}, ux = {}, uy = {}, uz = {};
    window.sceneViewer.getLookatParameters(ex, ey, ez, ix, iy, iz, ux, uy, uz);

    window.sceneViewer.setLookatParametersNonSkew(-3487.23, iy.value, iz.value, ix.value, iy.value, iz.value, 0, 0, 1);
//    window.sceneViewer.setLookatParametersNonSkew(-3487.23, 173.616, -1017.48, 288.624, 173.616, -1017.48, 0, 0, 1);
}

function right_side_view()
{
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

    var ex = {}, ey = {}, ez = {}, ix = {}, iy = {}, iz = {}, ux = {}, uy = {}, uz = {};
    window.sceneViewer.getLookatParameters(ex, ey, ez, ix, iy, iz, ux, uy, uz);

    window.sceneViewer.setLookatParametersNonSkew(4064.48, iy.value, iz.value, ix.value, iy.value, iz.value, 0, 0, 1);
//    window.sceneViewer.setLookatParametersNonSkew(4064.48, 173.616, -1017.48, 288.624, 173.616, -1017.48, 0, 0, 1);
}

function view_all()
{
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
    window.sceneViewer.viewAll();
}


//////////////////////////////////////

function view_la_norm()
{
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
    window.commandData.executeCommand("gfx read nodes memory:/la_norm.exnode;");
//    window.commandData.executeCommand("gfx read data memory:/la_normalised.exdata;");
}

function view_ra_norm()
{
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
    window.commandData.executeCommand("gfx read nodes memory:/ra_norm.exnode;");
//    window.commandData.executeCommand("gfx read data memory:/ra_normalised.exdata;");
}

function view_li_norm()
{
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
    window.commandData.executeCommand("gfx read nodes memory:/li_norm.exnode;");
//    window.commandData.executeCommand("gfx read data memory:/li_normalised.exdata;");
}

function view_ri_norm()
{
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
    window.commandData.executeCommand("gfx read nodes memory:/ri_norm.exnode;");
//    window.commandData.executeCommand("gfx read data memory:/ri_normalised.exdata;");
}

function view_ltis_norm()
{
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
    window.commandData.executeCommand("gfx read nodes memory:/ltis_norm.exnode;");
}

function view_rtis_norm()
{
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
    window.commandData.executeCommand("gfx read nodes memory:/rtis_norm.exnode;");
}

function view_lpop_norm()
{
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
    window.commandData.executeCommand("gfx read nodes memory:/lpop_norm.exnode;");
}

function view_rpop_norm()
{
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
    window.commandData.executeCommand("gfx read nodes memory:/rpop_norm.exnode;");
}

function view_lepit_norm()
{
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
    window.commandData.executeCommand("gfx read nodes memory:/lepit_norm.exnode;");
}

function view_repit_norm()
{
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
    window.commandData.executeCommand("gfx read nodes memory:/repit_norm.exnode;");
}

function view_1NF_norm()
{
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
    window.commandData.executeCommand("gfx read nodes memory:/1_NF_norm.exnode;");
}

function view_2and_more_NFs_norm()
{
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
    window.commandData.executeCommand("gfx read nodes memory:/2and_more_NFs_norm.exnode;");
}

function view_3and_more_NFs_norm()
{
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
    window.commandData.executeCommand("gfx read nodes memory:/3and_more_NFs_norm.exnode;");
}

function view_4and_more_NFs_norm()
{
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
    window.commandData.executeCommand("gfx read nodes memory:/4and_more_NFs_norm.exnode;");
}


/*function contours_on()
{
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
    window.commandData.executeCommand("gfx modify spectrum default linear reverse range 0 100 banded number_of_bands 20 band_ratio 0.2 component 1;");
}

function contours_off()
{
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
    window.commandData.executeCommand("gfx modify spectrum default clear");
    window.commandData.executeCommand("gfx mod spectrum default linear reverse range 0 100 extend_above extend_below rainbow colour_range 0 1 ambient diffuse component 1");
}*/

function checkbutton_contours_toggled()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  var image = document.getElementById('spectrum');

  var state=document.getElementById('contours_checkbutton').checked;
  if(state){
    window.commandData.executeCommand("gfx modify spectrum default linear reverse range 0 100 extend_below banded number_of_bands 10 band_ratio 0.2 component 1;");
    image.src = "spectrum_bar_contours.jpg";
  }else {
    window.commandData.executeCommand("gfx modify spectrum default clear");
    window.commandData.executeCommand("gfx mod spectrum default linear reverse range 0 100 extend_above extend_below rainbow colour_range 0 1 ambient diffuse component 1");
    image.src = "spectrum_bar.jpg";
  }
}
